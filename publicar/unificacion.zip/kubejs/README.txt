Unificación del modpack TFC Create
- config/almostunified/: qué objetos se consideran el mismo y cuál gana (TFC primero).
- kubejs/data/unificado/recipe/: recetas nuevas que conectan mods.
- kubejs/data/unificado/tfc/food/: caducidad y nutrición TFC para la comida de otros mods.
- kubejs/data/<mod>/recipe/: recetas desactivadas (duplicados).
- millenaire-custom/tfc_unificado/: los aldeanos de Millénaire usan comida y metales de TFC.
