// Oculta en JEI los objetos que se han sustituido por el de otro mod.
// (Almost Unified ya oculta automáticamente todos los duplicados de comida y metales.)
RecipeViewerEvents.removeEntriesCompletely('item', event => {
  event.remove('farmersdelight:iron_knife')
  event.remove('farmersdelight:flint_knife')
  event.remove('moredelight:wooden_knife')
  event.remove('moredelight:stone_knife')
})
